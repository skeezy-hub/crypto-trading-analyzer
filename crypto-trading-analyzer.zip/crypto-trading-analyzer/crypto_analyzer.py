"""
Crypto Trading Analyzer - Main Interface
Complete crypto technical analysis tool with TradingView-style charts and professional analysis
"""

import sys
import os
import argparse
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
import warnings
warnings.filterwarnings('ignore')

# Import our modules
from data_fetcher import DataFetcher
from technical_indicators import TechnicalIndicators
from chart_generator import ChartGenerator
from analysis_engine import AnalysisEngine


class CryptoAnalyzer:
    def __init__(self, exchange: str = 'binance'):
        """
        Initialize the Crypto Trading Analyzer
        
        Args:
            exchange: Exchange name to use for data fetching (default: binance)
        """
        self.exchange_name = exchange
        self.data_fetcher = DataFetcher(exchange)
        self.current_analysis = None
        
        print(f"🚀 Crypto Trading Analyzer initialized with {exchange.upper()} exchange")
    
    def analyze_symbol(self, 
                      symbol: str, 
                      timeframe: str = '1h', 
                      days_back: int = 30,
                      save_chart: bool = True,
                      chart_format: str = 'png',
                      show_chart: bool = False) -> Dict[str, Any]:
        """
        Perform complete technical analysis for a cryptocurrency symbol
        
        Args:
            symbol: Trading pair (e.g., 'BTC/USDT', 'ETH/USDT', or just 'BTC', 'ETH')
            timeframe: Chart timeframe ('1m', '5m', '15m', '30m', '1h', '2h', '4h', '6h', '12h', '1d', '3d', '1w')
            days_back: Number of days of historical data to fetch
            save_chart: Whether to save the chart as an image
            chart_format: Chart output format ('png', 'jpg', 'svg', 'pdf', 'html')
            show_chart: Whether to display the chart in browser
            
        Returns:
            Dictionary containing analysis results, chart path, and key metrics
        """
        try:
            print(f"\n📊 Starting analysis for {symbol} ({timeframe})...")
            
            # Step 1: Fetch OHLCV data
            print("📈 Fetching market data...")
            df = self.data_fetcher.get_historical_data_range(symbol, timeframe, days_back)
            
            if df.empty:
                raise ValueError(f"No data available for {symbol}")
            
            print(f"✅ Retrieved {len(df)} candles from {df.index[0]} to {df.index[-1]}")
            
            # Step 2: Calculate technical indicators
            print("🔍 Calculating technical indicators...")
            indicators = TechnicalIndicators(df)
            df_with_indicators = indicators.get_all_indicators()
            
            # Step 3: Find support and resistance levels
            sr_levels = indicators.find_support_resistance()
            
            print(f"✅ Found {len(sr_levels['support'])} support and {len(sr_levels['resistance'])} resistance levels")
            
            # Step 4: Generate chart
            print("📈 Generating TradingView-style chart...")
            chart_generator = ChartGenerator(df_with_indicators, symbol, timeframe)
            
            fig = chart_generator.create_chart(
                include_volume=True,
                include_rsi=True,
                include_macd=True,
                ema_periods=[20, 50],
                support_resistance=sr_levels,
                height=800
            )
            
            chart_path = None
            if save_chart:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                symbol_clean = symbol.replace('/', '_')
                filename = f"{symbol_clean}_{timeframe}_{timestamp}"
                chart_path = chart_generator.save_chart(filename, chart_format)
            
            if show_chart:
                chart_generator.show_chart()
            
            # Step 5: Generate technical analysis
            print("📝 Generating technical analysis...")
            analysis_engine = AnalysisEngine(df_with_indicators, symbol, timeframe)
            analysis_text = analysis_engine.generate_analysis()
            
            # Step 6: Get key metrics and signals
            key_levels = analysis_engine.get_key_levels()
            trading_signals = analysis_engine.get_trading_signals()
            
            # Compile results
            results = {
                'symbol': symbol,
                'timeframe': timeframe,
                'exchange': self.exchange_name,
                'analysis_time': datetime.now().isoformat(),
                'data_points': len(df),
                'date_range': {
                    'start': df.index[0].isoformat(),
                    'end': df.index[-1].isoformat()
                },
                'current_price': float(df['close'].iloc[-1]),
                'analysis_text': analysis_text,
                'key_levels': key_levels,
                'trading_signals': trading_signals,
                'support_resistance': sr_levels,
                'chart_path': chart_path,
                'raw_data': df_with_indicators
            }
            
            self.current_analysis = results
            
            print("✅ Analysis complete!")
            print("\n" + "="*80)
            print(analysis_text)
            print("="*80)
            
            return results
            
        except Exception as e:
            print(f"❌ Error during analysis: {str(e)}")
            raise
    
    def quick_analysis(self, symbol: str, timeframe: str = '4h') -> str:
        """
        Generate a quick analysis summary
        
        Args:
            symbol: Trading pair symbol
            timeframe: Chart timeframe
            
        Returns:
            Condensed analysis text
        """
        try:
            results = self.analyze_symbol(symbol, timeframe, days_back=14, save_chart=False)
            
            # Extract key information
            current_price = results['current_price']
            trend = results['trading_signals']['overall_bias']
            signal = results['trading_signals']['overall_signal']
            key_support = results['key_levels']['key_support']
            key_resistance = results['key_levels']['key_resistance']
            
            quick_summary = f"""
🔥 QUICK ANALYSIS: {symbol}

Current Price: ${current_price:,.2f}
Trend: {trend.upper()}
Signal: {signal}
Key Support: ${key_support:,.2f} ({((current_price - key_support)/current_price*100):+.1f}%)
Key Resistance: ${key_resistance:,.2f} ({((key_resistance - current_price)/current_price*100):+.1f}%)

{results['analysis_text'].split('🎲 TRADING SCENARIOS')[0]}"""
            
            return quick_summary
            
        except Exception as e:
            return f"❌ Quick analysis failed: {str(e)}"
    
    def compare_timeframes(self, symbol: str, timeframes: list = ['1h', '4h', '1d']) -> Dict[str, Any]:
        """
        Compare analysis across multiple timeframes
        
        Args:
            symbol: Trading pair symbol
            timeframes: List of timeframes to analyze
            
        Returns:
            Dictionary with analysis for each timeframe
        """
        comparison = {
            'symbol': symbol,
            'comparison_time': datetime.now().isoformat(),
            'timeframes': {}
        }
        
        print(f"\n🔄 Multi-timeframe analysis for {symbol}")
        print("─" * 50)
        
        for tf in timeframes:
            try:
                print(f"\n📊 Analyzing {tf} timeframe...")
                results = self.analyze_symbol(symbol, tf, save_chart=False, days_back=20)
                
                comparison['timeframes'][tf] = {
                    'trend': results['trading_signals']['overall_bias'],
                    'signal': results['trading_signals']['overall_signal'],
                    'current_price': results['current_price'],
                    'key_support': results['key_levels']['key_support'],
                    'key_resistance': results['key_levels']['key_resistance'],
                    'rsi': results['trading_signals']['momentum']
                }
                
            except Exception as e:
                print(f"❌ Failed to analyze {tf}: {str(e)}")
                comparison['timeframes'][tf] = {'error': str(e)}
        
        # Print comparison summary
        print("\n" + "="*60)
        print("📊 MULTI-TIMEFRAME SUMMARY")
        print("="*60)
        
        print(f"{'Timeframe':<10} {'Trend':<10} {'Signal':<12} {'Price':<12}")
        print("─" * 50)
        
        for tf, data in comparison['timeframes'].items():
            if 'error' not in data:
                print(f"{tf:<10} {data['trend']:<10} {data['signal']:<12} ${data['current_price']:>9,.2f}")
        
        return comparison
    
    def get_available_symbols(self, limit: int = 50) -> list:
        """Get list of available trading symbols"""
        try:
            symbols = self.data_fetcher.get_available_symbols()
            return symbols[:limit]
        except Exception as e:
            print(f"❌ Error fetching symbols: {str(e)}")
            return []
    
    def validate_inputs(self, symbol: str, timeframe: str) -> tuple:
        """
        Validate and format inputs
        
        Returns:
            Tuple of (validated_symbol, validated_timeframe, is_valid)
        """
        # Format symbol
        if '/' not in symbol:
            symbol = f"{symbol.upper()}/USDT"
        else:
            symbol = symbol.upper()
        
        # Validate timeframe
        valid_timeframes = ['1m', '3m', '5m', '15m', '30m', '1h', '2h', '4h', '6h', '8h', '12h', '1d', '3d', '1w']
        if timeframe not in valid_timeframes:
            print(f"❌ Invalid timeframe. Valid options: {', '.join(valid_timeframes)}")
            return symbol, timeframe, False
        
        # Validate symbol with exchange
        if not self.data_fetcher.validate_symbol(symbol):
            print(f"❌ Symbol {symbol} not available on {self.exchange_name}")
            return symbol, timeframe, False
        
        return symbol, timeframe, True


def main():
    """Main CLI interface"""
    parser = argparse.ArgumentParser(description='Crypto Trading Analyzer - Professional Technical Analysis')
    
    parser.add_argument('symbol', help='Trading symbol (e.g., BTC/USDT, ETH, DOGE)')
    parser.add_argument('-t', '--timeframe', default='4h', 
                       help='Timeframe (1m, 5m, 15m, 30m, 1h, 2h, 4h, 6h, 12h, 1d, 3d, 1w)')
    parser.add_argument('-d', '--days', type=int, default=30, 
                       help='Days of historical data (default: 30)')
    parser.add_argument('-e', '--exchange', default='binance', 
                       help='Exchange to use (default: binance)')
    parser.add_argument('--no-chart', action='store_true', 
                       help='Skip chart generation')
    parser.add_argument('--show-chart', action='store_true', 
                       help='Display chart in browser')
    parser.add_argument('--format', default='png', 
                       choices=['png', 'jpg', 'svg', 'pdf', 'html'],
                       help='Chart output format')
    parser.add_argument('--quick', action='store_true', 
                       help='Generate quick analysis only')
    parser.add_argument('--multi-tf', action='store_true', 
                       help='Multi-timeframe analysis')
    
    args = parser.parse_args()
    
    try:
        # Initialize analyzer
        analyzer = CryptoAnalyzer(args.exchange)
        
        # Validate inputs
        symbol, timeframe, is_valid = analyzer.validate_inputs(args.symbol, args.timeframe)
        if not is_valid:
            return
        
        # Perform analysis based on mode
        if args.quick:
            print(analyzer.quick_analysis(symbol, timeframe))
        elif args.multi_tf:
            analyzer.compare_timeframes(symbol)
        else:
            analyzer.analyze_symbol(
                symbol=symbol,
                timeframe=timeframe,
                days_back=args.days,
                save_chart=not args.no_chart,
                chart_format=args.format,
                show_chart=args.show_chart
            )
    
    except KeyboardInterrupt:
        print("\n👋 Analysis interrupted by user")
    except Exception as e:
        print(f"❌ Analysis failed: {str(e)}")


if __name__ == "__main__":
    if len(sys.argv) == 1:
        # Interactive mode if no arguments provided
        print("🚀 Crypto Trading Analyzer - Interactive Mode")
        print("=" * 50)
        
        analyzer = CryptoAnalyzer()
        
        while True:
            try:
                print("\nOptions:")
                print("1. Analyze a symbol")
                print("2. Quick analysis")
                print("3. Multi-timeframe analysis")
                print("4. List available symbols")
                print("5. Exit")
                
                choice = input("\nSelect option (1-5): ").strip()
                
                if choice == '1':
                    symbol = input("Enter symbol (e.g., BTC, ETH/USDT): ").strip()
                    timeframe = input("Enter timeframe (default 4h): ").strip() or '4h'
                    days = input("Days of data (default 30): ").strip()
                    days = int(days) if days.isdigit() else 30
                    
                    analyzer.analyze_symbol(symbol, timeframe, days)
                
                elif choice == '2':
                    symbol = input("Enter symbol: ").strip()
                    timeframe = input("Enter timeframe (default 4h): ").strip() or '4h'
                    print(analyzer.quick_analysis(symbol, timeframe))
                
                elif choice == '3':
                    symbol = input("Enter symbol: ").strip()
                    analyzer.compare_timeframes(symbol)
                
                elif choice == '4':
                    symbols = analyzer.get_available_symbols(20)
                    print("\nTop 20 available symbols:")
                    for i, sym in enumerate(symbols, 1):
                        print(f"{i:2d}. {sym}")
                
                elif choice == '5':
                    print("👋 Goodbye!")
                    break
                
                else:
                    print("❌ Invalid choice. Please select 1-5.")
                    
            except KeyboardInterrupt:
                print("\n👋 Goodbye!")
                break
            except Exception as e:
                print(f"❌ Error: {str(e)}")
    else:
        # CLI mode with arguments
        main()
