"""
Technical Indicators Module for Crypto Trading Analyzer
Implements various technical indicators including EMA, RSI, MACD, and support/resistance detection
"""

import pandas as pd
import numpy as np
from typing import List, Tuple, Dict, Optional
from scipy.signal import argrelextrema
import ta


class TechnicalIndicators:
    def __init__(self, df: pd.DataFrame):
        """
        Initialize with OHLCV DataFrame
        
        Args:
            df: DataFrame with OHLCV data (timestamp index, open, high, low, close, volume columns)
        """
        self.df = df.copy()
        self.indicators = {}
        
    def calculate_ema(self, period: int = 20, column: str = 'close') -> pd.Series:
        """Calculate Exponential Moving Average"""
        ema = self.df[column].ewm(span=period, adjust=False).mean()
        self.indicators[f'EMA_{period}'] = ema
        return ema
    
    def calculate_sma(self, period: int = 20, column: str = 'close') -> pd.Series:
        """Calculate Simple Moving Average"""
        sma = self.df[column].rolling(window=period).mean()
        self.indicators[f'SMA_{period}'] = sma
        return sma
    
    def calculate_rsi(self, period: int = 14, column: str = 'close') -> pd.Series:
        """Calculate Relative Strength Index"""
        rsi = ta.momentum.RSIIndicator(self.df[column], window=period).rsi()
        self.indicators['RSI'] = rsi
        return rsi
    
    def calculate_macd(self, fast: int = 12, slow: int = 26, signal: int = 9, column: str = 'close') -> Dict[str, pd.Series]:
        """Calculate MACD (Moving Average Convergence Divergence)"""
        macd_indicator = ta.trend.MACD(self.df[column], window_fast=fast, window_slow=slow, window_sign=signal)
        
        macd_line = macd_indicator.macd()
        macd_signal = macd_indicator.macd_signal()
        macd_histogram = macd_indicator.macd_diff()
        
        self.indicators['MACD'] = macd_line
        self.indicators['MACD_Signal'] = macd_signal
        self.indicators['MACD_Histogram'] = macd_histogram
        
        return {
            'MACD': macd_line,
            'MACD_Signal': macd_signal,
            'MACD_Histogram': macd_histogram
        }
    
    def calculate_bollinger_bands(self, period: int = 20, std_dev: float = 2, column: str = 'close') -> Dict[str, pd.Series]:
        """Calculate Bollinger Bands"""
        bb_indicator = ta.volatility.BollingerBands(self.df[column], window=period, window_dev=std_dev)
        
        bb_upper = bb_indicator.bollinger_hband()
        bb_middle = bb_indicator.bollinger_mavg()
        bb_lower = bb_indicator.bollinger_lband()
        
        self.indicators['BB_Upper'] = bb_upper
        self.indicators['BB_Middle'] = bb_middle
        self.indicators['BB_Lower'] = bb_lower
        
        return {
            'BB_Upper': bb_upper,
            'BB_Middle': bb_middle,
            'BB_Lower': bb_lower
        }
    
    def calculate_stochastic(self, k_period: int = 14, d_period: int = 3) -> Dict[str, pd.Series]:
        """Calculate Stochastic Oscillator"""
        stoch_indicator = ta.momentum.StochasticOscillator(
            self.df['high'], self.df['low'], self.df['close'], 
            window=k_period, smooth_window=d_period
        )
        
        stoch_k = stoch_indicator.stoch()
        stoch_d = stoch_indicator.stoch_signal()
        
        self.indicators['Stoch_K'] = stoch_k
        self.indicators['Stoch_D'] = stoch_d
        
        return {
            'Stoch_K': stoch_k,
            'Stoch_D': stoch_d
        }
    
    def find_support_resistance(self, window: int = 20, min_strength: int = 2) -> Dict[str, List[Tuple[float, int]]]:
        """
        Find support and resistance levels using local extrema
        
        Args:
            window: Window size for finding local extrema
            min_strength: Minimum number of touches to consider a level significant
            
        Returns:
            Dictionary with 'support' and 'resistance' levels as (price, strength) tuples
        """
        highs = self.df['high'].values
        lows = self.df['low'].values
        
        # Find local maxima (resistance) and minima (support)
        resistance_indices = argrelextrema(highs, np.greater, order=window)[0]
        support_indices = argrelextrema(lows, np.less, order=window)[0]
        
        # Get resistance levels
        resistance_levels = []
        for idx in resistance_indices:
            price = highs[idx]
            resistance_levels.append(price)
        
        # Get support levels
        support_levels = []
        for idx in support_indices:
            price = lows[idx]
            support_levels.append(price)
        
        # Group similar levels and count strength
        def group_levels(levels, tolerance=0.01):
            grouped = []
            for level in levels:
                found_group = False
                for i, (group_level, strength) in enumerate(grouped):
                    if abs(level - group_level) / group_level < tolerance:
                        # Update group level to average and increase strength
                        new_level = (group_level * strength + level) / (strength + 1)
                        grouped[i] = (new_level, strength + 1)
                        found_group = True
                        break
                if not found_group:
                    grouped.append((level, 1))
            
            # Filter by minimum strength and sort by strength
            significant_levels = [(level, strength) for level, strength in grouped if strength >= min_strength]
            return sorted(significant_levels, key=lambda x: x[1], reverse=True)
        
        significant_resistance = group_levels(resistance_levels)
        significant_support = group_levels(support_levels)
        
        self.indicators['Support_Levels'] = significant_support
        self.indicators['Resistance_Levels'] = significant_resistance
        
        return {
            'support': significant_support,
            'resistance': significant_resistance
        }
    
    def calculate_volume_profile(self, bins: int = 20) -> Dict[str, np.ndarray]:
        """Calculate Volume Profile"""
        price_range = self.df['high'].max() - self.df['low'].min()
        bin_size = price_range / bins
        
        # Create price bins
        min_price = self.df['low'].min()
        price_bins = np.arange(min_price, min_price + price_range + bin_size, bin_size)
        
        # Calculate volume for each price bin
        volume_profile = np.zeros(len(price_bins) - 1)
        
        for i, row in self.df.iterrows():
            # Distribute volume across the OHLC range
            price_points = [row['open'], row['high'], row['low'], row['close']]
            for price in price_points:
                bin_idx = min(int((price - min_price) / bin_size), len(volume_profile) - 1)
                volume_profile[bin_idx] += row['volume'] / 4  # Divide by 4 since we're using 4 price points
        
        # Find Point of Control (POC) - price level with highest volume
        poc_idx = np.argmax(volume_profile)
        poc_price = price_bins[poc_idx] + bin_size / 2
        
        self.indicators['Volume_Profile'] = volume_profile
        self.indicators['POC_Price'] = poc_price
        
        return {
            'volume_profile': volume_profile,
            'price_bins': price_bins,
            'poc_price': poc_price
        }
    
    def calculate_atr(self, period: int = 14) -> pd.Series:
        """Calculate Average True Range"""
        atr = ta.volatility.AverageTrueRange(self.df['high'], self.df['low'], self.df['close'], window=period).average_true_range()
        self.indicators['ATR'] = atr
        return atr
    
    def calculate_adx(self, period: int = 14) -> pd.Series:
        """Calculate Average Directional Index (trend strength)"""
        adx = ta.trend.ADXIndicator(self.df['high'], self.df['low'], self.df['close'], window=period).adx()
        self.indicators['ADX'] = adx
        return adx
    
    def get_trend_direction(self, ema_short: int = 20, ema_long: int = 50) -> str:
        """
        Determine overall trend direction based on EMAs and price action
        
        Returns:
            'bullish', 'bearish', or 'sideways'
        """
        if len(self.df) < max(ema_short, ema_long):
            return 'insufficient_data'
        
        ema_short_series = self.calculate_ema(ema_short)
        ema_long_series = self.calculate_ema(ema_long)
        
        current_price = self.df['close'].iloc[-1]
        ema_short_current = ema_short_series.iloc[-1]
        ema_long_current = ema_long_series.iloc[-1]
        
        # Check EMA alignment
        emas_bullish = ema_short_current > ema_long_current
        price_above_emas = current_price > ema_short_current > ema_long_current
        
        # Check recent price action (last 10 periods)
        recent_closes = self.df['close'].tail(10)
        price_trend = (recent_closes.iloc[-1] - recent_closes.iloc[0]) / recent_closes.iloc[0]
        
        # Determine trend
        if price_above_emas and emas_bullish and price_trend > 0.02:  # 2% upward movement
            return 'bullish'
        elif not emas_bullish and current_price < ema_long_current and price_trend < -0.02:
            return 'bearish'
        else:
            return 'sideways'
    
    def get_all_indicators(self) -> pd.DataFrame:
        """Calculate all indicators and return combined DataFrame"""
        # Calculate all indicators
        self.calculate_ema(20)
        self.calculate_ema(50)
        self.calculate_ema(200)
        self.calculate_sma(20)
        self.calculate_sma(50)
        self.calculate_rsi()
        self.calculate_macd()
        self.calculate_bollinger_bands()
        self.calculate_stochastic()
        self.calculate_atr()
        self.calculate_adx()
        self.find_support_resistance()
        
        # Combine with original data
        result_df = self.df.copy()
        
        # Add calculated indicators to DataFrame
        for name, indicator in self.indicators.items():
            if isinstance(indicator, pd.Series):
                result_df[name] = indicator
        
        return result_df
    
    def get_current_signals(self) -> Dict[str, any]:
        """Get current trading signals based on indicators"""
        if self.df.empty:
            return {}
        
        # Ensure indicators are calculated
        self.get_all_indicators()
        
        current_price = self.df['close'].iloc[-1]
        
        signals = {
            'current_price': current_price,
            'trend': self.get_trend_direction(),
            'rsi': self.indicators.get('RSI', pd.Series()).iloc[-1] if 'RSI' in self.indicators else None,
            'rsi_signal': self._get_rsi_signal(),
            'macd_signal': self._get_macd_signal(),
            'bb_position': self._get_bb_position(),
            'support_levels': self.indicators.get('Support_Levels', []),
            'resistance_levels': self.indicators.get('Resistance_Levels', []),
            'volume_trend': self._get_volume_trend(),
        }
        
        return signals
    
    def _get_rsi_signal(self) -> str:
        """Get RSI signal"""
        if 'RSI' not in self.indicators:
            return 'neutral'
        
        rsi = self.indicators['RSI'].iloc[-1]
        if rsi > 70:
            return 'overbought'
        elif rsi < 30:
            return 'oversold'
        elif rsi > 50:
            return 'bullish'
        else:
            return 'bearish'
    
    def _get_macd_signal(self) -> str:
        """Get MACD signal"""
        if 'MACD' not in self.indicators or 'MACD_Signal' not in self.indicators:
            return 'neutral'
        
        macd = self.indicators['MACD'].iloc[-1]
        signal = self.indicators['MACD_Signal'].iloc[-1]
        
        if macd > signal:
            return 'bullish'
        else:
            return 'bearish'
    
    def _get_bb_position(self) -> str:
        """Get Bollinger Bands position"""
        if 'BB_Upper' not in self.indicators:
            return 'neutral'
        
        current_price = self.df['close'].iloc[-1]
        bb_upper = self.indicators['BB_Upper'].iloc[-1]
        bb_lower = self.indicators['BB_Lower'].iloc[-1]
        bb_middle = self.indicators['BB_Middle'].iloc[-1]
        
        if current_price > bb_upper:
            return 'above_upper'
        elif current_price < bb_lower:
            return 'below_lower'
        elif current_price > bb_middle:
            return 'above_middle'
        else:
            return 'below_middle'
    
    def _get_volume_trend(self) -> str:
        """Analyze volume trend"""
        if len(self.df) < 20:
            return 'insufficient_data'
        
        recent_volume = self.df['volume'].tail(10).mean()
        previous_volume = self.df['volume'].tail(20).head(10).mean()
        
        volume_change = (recent_volume - previous_volume) / previous_volume
        
        if volume_change > 0.2:
            return 'increasing'
        elif volume_change < -0.2:
            return 'decreasing'
        else:
            return 'stable'


# Example usage
if __name__ == "__main__":
    # This would normally be called with real OHLCV data
    print("Technical Indicators module loaded successfully")
    print("Use with OHLCV DataFrame to calculate indicators")
