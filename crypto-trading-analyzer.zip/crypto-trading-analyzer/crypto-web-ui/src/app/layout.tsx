import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Crypto Trading Analyzer | Professional Technical Analysis',
  description: 'Advanced cryptocurrency technical analysis with TradingView-style charts and AI-powered insights',
  keywords: 'cryptocurrency, trading, technical analysis, charts, bitcoin, ethereum, crypto signals',
  authors: [{ name: 'Crypto Trading Analyzer' }],
  viewport: 'width=device-width, initial-scale=1',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="dark">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
      </head>
      <body className="min-h-screen bg-gradient-to-br from-cyber-darker via-cyber-dark to-cyber-gray font-cyber antialiased">
        <div className="relative min-h-screen cyber-grid">
          <div className="absolute inset-0 bg-gradient-to-br from-transparent via-neon-blue/5 to-neon-purple/5 pointer-events-none" />
          {children}
        </div>
      </body>
    </html>
  )
}
