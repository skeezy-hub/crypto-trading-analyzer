import CryptoDashboard from '@/components/CryptoDashboard'

export default function Home() {
  return <CryptoDashboard />
}
