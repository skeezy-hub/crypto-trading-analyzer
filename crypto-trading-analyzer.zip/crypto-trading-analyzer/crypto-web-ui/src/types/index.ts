export interface CryptoData {
  symbol: string
  timeframe: string
  current_price: number
  price_change_24h: number
  price_change_percentage_24h: number
  volume_24h: number
  market_cap: number
  timestamp: string
}

export interface TechnicalIndicators {
  rsi: number
  macd: {
    macd: number
    signal: number
    histogram: number
  }
  ema_20: number
  ema_50: number
  bollinger_bands: {
    upper: number
    middle: number
    lower: number
  }
  support_levels: Array<{ price: number; strength: number }>
  resistance_levels: Array<{ price: number; strength: number }>
}

export interface TradingSignals {
  overall_bias: 'bullish' | 'bearish' | 'sideways'
  overall_signal: 'STRONG_BUY' | 'BUY' | 'HOLD' | 'SELL' | 'STRONG_SELL'
  momentum: string
  macd_direction: string
  volume_confirmation: string
}

export interface AnalysisResult {
  symbol: string
  timeframe: string
  exchange: string
  analysis_time: string
  current_price: number
  analysis_text: string
  key_levels: {
    current_price: number
    key_support: number | null
    key_resistance: number | null
    secondary_support: number | null
    secondary_resistance: number | null
  }
  trading_signals: TradingSignals
  support_resistance: {
    support: Array<[number, number]>
    resistance: Array<[number, number]>
  }
}

export interface ChartData {
  timestamp: string
  open: number
  high: number
  low: number
  close: number
  volume: number
}

export interface WatchlistItem {
  symbol: string
  name: string
  price: number
  change_24h: number
  change_percentage_24h: number
  is_favorite: boolean
}

export type TimeframeOption = '1m' | '5m' | '15m' | '30m' | '1h' | '2h' | '4h' | '6h' | '12h' | '1d' | '3d' | '1w'

export interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: string
  message?: string
}
