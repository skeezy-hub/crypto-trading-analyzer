import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatPrice(price: number): string {
  if (price >= 1000000) {
    return `$${(price / 1000000).toFixed(2)}M`
  } else if (price >= 1000) {
    return `$${(price / 1000).toFixed(2)}K`
  } else if (price >= 1) {
    return `$${price.toFixed(2)}`
  } else {
    return `$${price.toFixed(6)}`
  }
}

export function formatPercentage(percentage: number): string {
  const sign = percentage >= 0 ? '+' : ''
  return `${sign}${percentage.toFixed(2)}%`
}

export function formatVolume(volume: number): string {
  if (volume >= 1000000000) {
    return `${(volume / 1000000000).toFixed(2)}B`
  } else if (volume >= 1000000) {
    return `${(volume / 1000000).toFixed(2)}M`
  } else if (volume >= 1000) {
    return `${(volume / 1000).toFixed(2)}K`
  } else {
    return volume.toFixed(2)
  }
}

export function getSignalColor(signal: string): string {
  switch (signal.toLowerCase()) {
    case 'strong_buy':
      return 'text-neon-green'
    case 'buy':
      return 'text-green-400'
    case 'hold':
      return 'text-neon-blue'
    case 'sell':
      return 'text-orange-400'
    case 'strong_sell':
      return 'text-neon-pink'
    default:
      return 'text-gray-400'
  }
}

export function getTrendColor(trend: string): string {
  switch (trend.toLowerCase()) {
    case 'bullish':
      return 'text-neon-green'
    case 'bearish':
      return 'text-neon-pink'
    case 'sideways':
      return 'text-neon-blue'
    default:
      return 'text-gray-400'
  }
}

export function getPriceChangeColor(change: number): string {
  if (change > 0) return 'text-neon-green'
  if (change < 0) return 'text-neon-pink'
  return 'text-neon-blue'
}

export function formatTimeframe(timeframe: string): string {
  const timeframeMap: { [key: string]: string } = {
    '1m': '1 Minute',
    '5m': '5 Minutes',
    '15m': '15 Minutes',
    '30m': '30 Minutes',
    '1h': '1 Hour',
    '2h': '2 Hours',
    '4h': '4 Hours',
    '6h': '6 Hours',
    '12h': '12 Hours',
    '1d': '1 Day',
    '3d': '3 Days',
    '1w': '1 Week',
  }
  return timeframeMap[timeframe] || timeframe
}

export function debounce<T extends (...args: any[]) => void>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout | null = null
  
  return (...args: Parameters<T>) => {
    const later = () => {
      timeout = null
      func(...args)
    }
    
    if (timeout) clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

export function throttle<T extends (...args: any[]) => void>(
  func: T,
  limit: number
): (...args: Parameters<T>) => void {
  let inThrottle: boolean = false
  
  return (...args: Parameters<T>) => {
    if (!inThrottle) {
      func(...args)
      inThrottle = true
      setTimeout(() => (inThrottle = false), limit)
    }
  }
}

export function generateWatchlistData() {
  const symbols = [
    { symbol: 'BTC/USDT', name: 'Bitcoin' },
    { symbol: 'ETH/USDT', name: 'Ethereum' },
    { symbol: 'BNB/USDT', name: 'Binance Coin' },
    { symbol: 'ADA/USDT', name: 'Cardano' },
    { symbol: 'SOL/USDT', name: 'Solana' },
    { symbol: 'DOT/USDT', name: 'Polkadot' },
    { symbol: 'MATIC/USDT', name: 'Polygon' },
    { symbol: 'LINK/USDT', name: 'Chainlink' },
    { symbol: 'AVAX/USDT', name: 'Avalanche' },
    { symbol: 'UNI/USDT', name: 'Uniswap' },
  ]
  
  return symbols.map(item => ({
    ...item,
    price: Math.random() * 1000 + 10,
    change_24h: (Math.random() - 0.5) * 100,
    change_percentage_24h: (Math.random() - 0.5) * 20,
    is_favorite: Math.random() > 0.7,
  }))
}
