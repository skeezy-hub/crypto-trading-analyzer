'use client'

import React, { useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Area, AreaChart, BarChart, Bar, ComposedChart } from 'recharts'
import { TrendingUp, TrendingDown, Activity, Volume2 } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { TimeframeOption } from '@/types'

interface TradingChartProps {
  symbol: string
  timeframe: TimeframeOption
}

// Generate sample chart data
const generateChartData = (symbol: string, timeframe: string) => {
  const data = []
  const basePrice = symbol.includes('BTC') ? 57000 : symbol.includes('ETH') ? 3000 : 1000
  let currentPrice = basePrice
  
  for (let i = 0; i < 100; i++) {
    const change = (Math.random() - 0.5) * (basePrice * 0.02)
    currentPrice = Math.max(currentPrice + change, basePrice * 0.8)
    
    const open = currentPrice
    const close = Math.max(open + (Math.random() - 0.5) * (basePrice * 0.01), basePrice * 0.8)
    const high = Math.max(open, close) + Math.random() * (basePrice * 0.005)
    const low = Math.min(open, close) - Math.random() * (basePrice * 0.005)
    const volume = Math.random() * 1000000 + 500000
    
    data.push({
      time: new Date(Date.now() - (100 - i) * 3600000).toISOString(),
      open: Number(open.toFixed(2)),
      high: Number(high.toFixed(2)),
      low: Number(low.toFixed(2)),
      close: Number(close.toFixed(2)),
      volume: Number(volume.toFixed(0)),
      ema20: Number((close * 0.98 + Math.random() * close * 0.04).toFixed(2)),
      ema50: Number((close * 0.96 + Math.random() * close * 0.08).toFixed(2)),
      rsi: Math.random() * 100,
      macd: (Math.random() - 0.5) * 100,
      macdSignal: (Math.random() - 0.5) * 80,
    })
    
    currentPrice = close
  }
  
  return data
}

const TradingChart: React.FC<TradingChartProps> = ({ symbol, timeframe }) => {
  const [chartData, setChartData] = useState<any[]>([])
  const [activeTab, setActiveTab] = useState<'price' | 'rsi' | 'macd' | 'volume'>('price')
  const [hoveredData, setHoveredData] = useState<any>(null)

  useEffect(() => {
    const data = generateChartData(symbol, timeframe)
    setChartData(data)
  }, [symbol, timeframe])

  const currentPrice = chartData.length > 0 ? chartData[chartData.length - 1]?.close : 0
  const previousPrice = chartData.length > 1 ? chartData[chartData.length - 2]?.close : currentPrice
  const priceChange = currentPrice - previousPrice
  const isPositive = priceChange >= 0

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload
      setHoveredData(data)
      
      return (
        <div className="glass-dark rounded-lg p-3 border border-neon-blue/30 shadow-lg">
          <p className="text-neon-blue text-sm font-medium">
            {new Date(label).toLocaleDateString()} {new Date(label).toLocaleTimeString()}
          </p>
          <div className="mt-2 space-y-1">
            {activeTab === 'price' && (
              <>
                <p className="text-xs text-gray-300">O: <span className="text-neon-blue">${data.open}</span></p>
                <p className="text-xs text-gray-300">H: <span className="text-neon-green">${data.high}</span></p>
                <p className="text-xs text-gray-300">L: <span className="text-neon-pink">${data.low}</span></p>
                <p className="text-xs text-gray-300">C: <span className="text-white font-medium">${data.close}</span></p>
              </>
            )}
            {activeTab === 'volume' && (
              <p className="text-xs text-gray-300">Volume: <span className="text-neon-blue">{data.volume.toLocaleString()}</span></p>
            )}
            {activeTab === 'rsi' && (
              <p className="text-xs text-gray-300">RSI: <span className="text-neon-purple">{data.rsi.toFixed(2)}</span></p>
            )}
            {activeTab === 'macd' && (
              <>
                <p className="text-xs text-gray-300">MACD: <span className="text-neon-blue">{data.macd.toFixed(2)}</span></p>
                <p className="text-xs text-gray-300">Signal: <span className="text-neon-pink">{data.macdSignal.toFixed(2)}</span></p>
              </>
            )}
          </div>
        </div>
      )
    }
    return null
  }

  const renderChart = () => {
    switch (activeTab) {
      case 'price':
        return (
          <ComposedChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <defs>
              <linearGradient id="priceGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#00d4ff" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#00d4ff" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#1a1a2e" opacity={0.3} />
            <XAxis 
              dataKey="time" 
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 12, fill: '#6b7280' }}
              tickFormatter={(value) => new Date(value).toLocaleDateString()}
            />
            <YAxis 
              domain={['dataMin - 100', 'dataMax + 100']}
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 12, fill: '#6b7280' }}
              tickFormatter={(value) => `$${value}`}
            />
            <Area
              type="monotone"
              dataKey="close"
              stroke="#00d4ff"
              strokeWidth={2}
              fill="url(#priceGradient)"
            />
            <Line
              type="monotone"
              dataKey="ema20"
              stroke="#00ff88"
              strokeWidth={1.5}
              dot={false}
              strokeDasharray="5 5"
            />
            <Line
              type="monotone"
              dataKey="ema50"
              stroke="#b537ff"
              strokeWidth={1.5}
              dot={false}
              strokeDasharray="5 5"
            />
            <CustomTooltip />
          </ComposedChart>
        )
      
      case 'volume':
        return (
          <BarChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1a1a2e" opacity={0.3} />
            <XAxis 
              dataKey="time" 
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 12, fill: '#6b7280' }}
              tickFormatter={(value) => new Date(value).toLocaleDateString()}
            />
            <YAxis 
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 12, fill: '#6b7280' }}
              tickFormatter={(value) => `${(value / 1000000).toFixed(1)}M`}
            />
            <Bar 
              dataKey="volume" 
              fill="#26a69a" 
              opacity={0.8}
              radius={[2, 2, 0, 0]}
            />
            <CustomTooltip />
          </BarChart>
        )
      
      case 'rsi':
        return (
          <AreaChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <defs>
              <linearGradient id="rsiGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#b537ff" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#b537ff" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#1a1a2e" opacity={0.3} />
            <XAxis 
              dataKey="time" 
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 12, fill: '#6b7280' }}
              tickFormatter={(value) => new Date(value).toLocaleDateString()}
            />
            <YAxis 
              domain={[0, 100]}
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 12, fill: '#6b7280' }}
            />
            <Area
              type="monotone"
              dataKey="rsi"
              stroke="#b537ff"
              strokeWidth={2}
              fill="url(#rsiGradient)"
            />
            {/* RSI levels */}
            <Line type="monotone" dataKey={() => 70} stroke="#ff00aa" strokeDasharray="3 3" strokeWidth={1} />
            <Line type="monotone" dataKey={() => 50} stroke="#6b7280" strokeDasharray="3 3" strokeWidth={1} />
            <Line type="monotone" dataKey={() => 30} stroke="#00ff88" strokeDasharray="3 3" strokeWidth={1} />
            <CustomTooltip />
          </AreaChart>
        )
      
      case 'macd':
        return (
          <ComposedChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1a1a2e" opacity={0.3} />
            <XAxis 
              dataKey="time" 
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 12, fill: '#6b7280' }}
              tickFormatter={(value) => new Date(value).toLocaleDateString()}
            />
            <YAxis 
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 12, fill: '#6b7280' }}
            />
            <Line
              type="monotone"
              dataKey="macd"
              stroke="#00d4ff"
              strokeWidth={2}
              dot={false}
            />
            <Line
              type="monotone"
              dataKey="macdSignal"
              stroke="#ff00aa"
              strokeWidth={2}
              dot={false}
            />
            <Line type="monotone" dataKey={() => 0} stroke="#6b7280" strokeDasharray="3 3" strokeWidth={1} />
            <CustomTooltip />
          </ComposedChart>
        )
      
      default:
        return null
    }
  }

  return (
    <div className="w-full h-full">
      {/* Chart Controls */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className={cn(
            "flex items-center gap-1 text-sm font-medium",
            isPositive ? "text-neon-green" : "text-neon-pink"
          )}>
            {isPositive ? (
              <TrendingUp className="w-4 h-4" />
            ) : (
              <TrendingDown className="w-4 h-4" />
            )}
            {isPositive ? '+' : ''}{priceChange.toFixed(2)}
          </div>
        </div>
        
        <div className="flex items-center gap-1 bg-cyber-dark/50 rounded-lg p-1">
          {[
            { key: 'price', label: 'Price', icon: Activity },
            { key: 'volume', label: 'Volume', icon: Volume2 },
            { key: 'rsi', label: 'RSI', icon: TrendingUp },
            { key: 'macd', label: 'MACD', icon: TrendingDown },
          ].map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setActiveTab(key as any)}
              className={cn(
                "flex items-center gap-1 px-3 py-1.5 rounded-md text-xs font-medium transition-all duration-200",
                activeTab === key
                  ? "bg-neon-blue/20 text-neon-blue cyber-glow"
                  : "text-gray-400 hover:text-neon-blue hover:bg-neon-blue/10"
              )}
            >
              <Icon className="w-3 h-3" />
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Chart */}
      <motion.div 
        className="w-full h-full"
        key={activeTab}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
      >
        <ResponsiveContainer width="100%" height="100%">
          {renderChart()}
        </ResponsiveContainer>
      </motion.div>

      {/* Chart Legend */}
      <div className="flex items-center justify-center gap-6 mt-4 text-xs">
        {activeTab === 'price' && (
          <>
            <div className="flex items-center gap-2">
              <div className="w-3 h-0.5 bg-neon-blue"></div>
              <span className="text-gray-400">Price</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-0.5 bg-neon-green border-dashed border-t"></div>
              <span className="text-gray-400">EMA 20</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-0.5 bg-neon-purple border-dashed border-t"></div>
              <span className="text-gray-400">EMA 50</span>
            </div>
          </>
        )}
        {activeTab === 'rsi' && (
          <>
            <div className="flex items-center gap-2">
              <div className="w-3 h-0.5 bg-neon-pink border-dashed border-t"></div>
              <span className="text-gray-400">Overbought (70)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-0.5 bg-neon-green border-dashed border-t"></div>
              <span className="text-gray-400">Oversold (30)</span>
            </div>
          </>
        )}
      </div>
    </div>
  )
}

export { TradingChart }
