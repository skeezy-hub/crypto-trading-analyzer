'use client'

import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Search, TrendingUp, TrendingDown, Activity, RefreshCw, Star, Settings, BarChart3 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { CyberCard } from '@/components/ui/card'
import { CyberInput } from '@/components/ui/input'
import { TradingChart } from '@/components/TradingChart'
import { AnalysisPanel } from '@/components/AnalysisPanel'
import { Watchlist } from '@/components/Watchlist'
import { TimeframeSelector } from '@/components/TimeframeSelector'
import { cn, formatPrice, formatPercentage, getPriceChangeColor, generateWatchlistData } from '@/lib/utils'
import type { TimeframeOption, WatchlistItem, AnalysisResult } from '@/types'

const CryptoDashboard = () => {
  const [selectedSymbol, setSelectedSymbol] = useState('BTC/USDT')
  const [selectedTimeframe, setSelectedTimeframe] = useState<TimeframeOption>('4h')
  const [searchQuery, setSearchQuery] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [analysisData, setAnalysisData] = useState<AnalysisResult | null>(null)
  const [watchlistData, setWatchlistData] = useState<WatchlistItem[]>([])
  const [currentPrice, setCurrentPrice] = useState(57842.33)
  const [priceChange, setPriceChange] = useState(2.45)
  const [isRefreshing, setIsRefreshing] = useState(false)

  // Initialize watchlist data
  useEffect(() => {
    setWatchlistData(generateWatchlistData())
  }, [])

  // Simulate real-time price updates
  useEffect(() => {
    const interval = setInterval(() => {
      const change = (Math.random() - 0.5) * 100
      setCurrentPrice(prev => Math.max(prev + change, 1000))
      setPriceChange((Math.random() - 0.5) * 5)
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  const handleSearch = async () => {
    if (!searchQuery.trim()) return
    
    setIsLoading(true)
    setSelectedSymbol(searchQuery.toUpperCase())
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      setSearchQuery('')
    }, 1500)
  }

  const handleRefresh = async () => {
    setIsRefreshing(true)
    
    // Simulate refresh
    setTimeout(() => {
      setIsRefreshing(false)
      setWatchlistData(generateWatchlistData())
    }, 1000)
  }

  const handleSymbolSelect = (symbol: string) => {
    setSelectedSymbol(symbol)
    setIsLoading(true)
    setTimeout(() => setIsLoading(false), 1000)
  }

  const handleTimeframeChange = (timeframe: TimeframeOption) => {
    setSelectedTimeframe(timeframe)
    setIsLoading(true)
    setTimeout(() => setIsLoading(false), 800)
  }

  return (
    <div className="min-h-screen p-4 lg:p-6">
      {/* Header */}
      <motion.header 
        className="mb-8"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          {/* Logo and Title */}
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-neon-blue to-neon-purple p-0.5">
                <div className="w-full h-full rounded-xl bg-cyber-dark flex items-center justify-center">
                  <BarChart3 className="w-6 h-6 text-neon-blue" />
                </div>
              </div>
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-neon-green rounded-full animate-pulse" />
            </div>
            <div>
              <h1 className="text-2xl lg:text-3xl font-bold text-glow bg-gradient-to-r from-neon-blue to-neon-purple bg-clip-text text-transparent">
                Crypto Analyzer
              </h1>
              <p className="text-sm text-muted-foreground">Professional Trading Terminal</p>
            </div>
          </div>

          {/* Search Bar */}
          <div className="flex items-center gap-3">
            <div className="relative flex-1 lg:w-80">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-neon-blue/60" />
              <CyberInput
                placeholder="Enter symbol (e.g., BTC/USDT, ETH)"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                className="pl-10 pr-4"
              />
            </div>
            <Button 
              variant="neon" 
              onClick={handleSearch}
              disabled={!searchQuery.trim() || isLoading}
              className="px-6"
            >
              {isLoading ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                'Analyze'
              )}
            </Button>
          </div>
        </div>
      </motion.header>

      {/* Main Content */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Left Sidebar - Watchlist */}
        <motion.aside 
          className="xl:col-span-3"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <CyberCard className="h-fit">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-neon-blue text-glow">Watchlist</h2>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={handleRefresh}
                  disabled={isRefreshing}
                  className="text-neon-blue hover:bg-neon-blue/10"
                >
                  <RefreshCw className={cn("w-4 h-4", isRefreshing && "animate-spin")} />
                </Button>
              </div>
              <Watchlist 
                data={watchlistData}
                selectedSymbol={selectedSymbol}
                onSymbolSelect={handleSymbolSelect}
              />
            </div>
          </CyberCard>
        </motion.aside>

        {/* Main Chart Area */}
        <motion.main 
          className="xl:col-span-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <CyberCard className="mb-6">
            {/* Price Header */}
            <div className="p-6 pb-4 border-b border-neon-blue/20">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div>
                    <h2 className="text-2xl font-bold text-neon-blue text-glow">
                      {selectedSymbol}
                    </h2>
                    <p className="text-sm text-muted-foreground">
                      Binance • {selectedTimeframe.toUpperCase()}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold">
                      {formatPrice(currentPrice)}
                    </div>
                    <div className={cn(
                      "text-sm font-medium flex items-center gap-1",
                      getPriceChangeColor(priceChange)
                    )}>
                      {priceChange >= 0 ? (
                        <TrendingUp className="w-4 h-4" />
                      ) : (
                        <TrendingDown className="w-4 h-4" />
                      )}
                      {formatPercentage(priceChange)}
                    </div>
                  </div>
                </div>

                {/* Timeframe Selector */}
                <TimeframeSelector
                  selected={selectedTimeframe}
                  onChange={handleTimeframeChange}
                />
              </div>
            </div>

            {/* Chart */}
            <div className="p-6">
              <div className="relative h-96 lg:h-[500px]">
                <AnimatePresence mode="wait">
                  {isLoading ? (
                    <motion.div
                      key="loading"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="absolute inset-0 flex items-center justify-center"
                    >
                      <div className="flex flex-col items-center gap-4">
                        <div className="relative">
                          <div className="w-12 h-12 border-2 border-neon-blue/30 rounded-full animate-spin">
                            <div className="absolute top-0 left-0 w-3 h-3 bg-neon-blue rounded-full"></div>
                          </div>
                        </div>
                        <p className="text-neon-blue/80">Loading chart data...</p>
                      </div>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="chart"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="w-full h-full"
                    >
                      <TradingChart 
                        symbol={selectedSymbol}
                        timeframe={selectedTimeframe}
                      />
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </CyberCard>
        </motion.main>

        {/* Right Sidebar - Analysis */}
        <motion.aside 
          className="xl:col-span-3"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <AnalysisPanel 
            symbol={selectedSymbol}
            timeframe={selectedTimeframe}
            analysisData={analysisData}
            isLoading={isLoading}
          />
        </motion.aside>
      </div>

      {/* Floating Action Buttons */}
      <motion.div 
        className="fixed bottom-6 right-6 flex flex-col gap-3"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, delay: 0.8 }}
      >
        <Button
          variant="cyber"
          size="icon"
          className="w-12 h-12 rounded-full shadow-lg hover:shadow-neon-blue/50"
          onClick={handleRefresh}
        >
          <Activity className="w-5 h-5" />
        </Button>
        <Button
          variant="neonPurple"
          size="icon"
          className="w-12 h-12 rounded-full shadow-lg hover:shadow-neon-purple/50"
        >
          <Settings className="w-5 h-5" />
        </Button>
      </motion.div>
    </div>
  )
}

export default CryptoDashboard
