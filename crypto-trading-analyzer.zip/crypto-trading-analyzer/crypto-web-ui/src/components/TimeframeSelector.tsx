'use client'

import React from 'react'
import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'
import type { TimeframeOption } from '@/types'

interface TimeframeSelectorProps {
  selected: TimeframeOption
  onChange: (timeframe: TimeframeOption) => void
}

const timeframes: { value: TimeframeOption; label: string }[] = [
  { value: '1m', label: '1m' },
  { value: '5m', label: '5m' },
  { value: '15m', label: '15m' },
  { value: '30m', label: '30m' },
  { value: '1h', label: '1h' },
  { value: '4h', label: '4h' },
  { value: '1d', label: '1d' },
  { value: '1w', label: '1w' },
]

const TimeframeSelector: React.FC<TimeframeSelectorProps> = ({ selected, onChange }) => {
  return (
    <div className="flex items-center gap-1 bg-cyber-dark/50 rounded-lg p-1 border border-neon-blue/20">
      {timeframes.map((timeframe) => (
        <motion.button
          key={timeframe.value}
          onClick={() => onChange(timeframe.value)}
          className={cn(
            "relative px-3 py-1.5 text-xs font-medium rounded-md transition-all duration-200",
            selected === timeframe.value
              ? "text-neon-blue"
              : "text-gray-400 hover:text-neon-blue"
          )}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          {selected === timeframe.value && (
            <motion.div
              layoutId="timeframe-bg"
              className="absolute inset-0 bg-neon-blue/20 rounded-md cyber-glow"
              initial={false}
              transition={{
                type: "spring",
                stiffness: 500,
                damping: 30
              }}
            />
          )}
          <span className="relative z-10">{timeframe.label}</span>
        </motion.button>
      ))}
    </div>
  )
}

export { TimeframeSelector }
