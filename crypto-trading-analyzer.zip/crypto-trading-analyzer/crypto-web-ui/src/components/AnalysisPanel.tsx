'use client'

import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { TrendingUp, TrendingDown, Activity, AlertTriangle, Target, Shield, Zap } from 'lucide-react'
import { CyberCard } from '@/components/ui/card'
import { cn, formatPrice, getSignalColor, getTrendColor } from '@/lib/utils'
import type { AnalysisResult, TimeframeOption } from '@/types'

interface AnalysisPanelProps {
  symbol: string
  timeframe: TimeframeOption
  analysisData: AnalysisResult | null
  isLoading: boolean
}

// Mock analysis data generator
const generateMockAnalysis = (symbol: string, timeframe: string): AnalysisResult => {
  const basePrice = symbol.includes('BTC') ? 57000 : symbol.includes('ETH') ? 3000 : 1000
  const signals = ['STRONG_BUY', 'BUY', 'HOLD', 'SELL', 'STRONG_SELL']
  const trends = ['bullish', 'bearish', 'sideways']
  
  return {
    symbol,
    timeframe,
    exchange: 'binance',
    analysis_time: new Date().toISOString(),
    current_price: basePrice + (Math.random() - 0.5) * basePrice * 0.1,
    analysis_text: `The market is showing ${trends[Math.floor(Math.random() * trends.length)]} momentum with current price action suggesting potential for continued movement. RSI indicates ${Math.random() > 0.5 ? 'oversold' : 'overbought'} conditions.`,
    key_levels: {
      current_price: basePrice,
      key_support: basePrice * 0.95,
      key_resistance: basePrice * 1.05,
      secondary_support: basePrice * 0.92,
      secondary_resistance: basePrice * 1.08,
    },
    trading_signals: {
      overall_bias: trends[Math.floor(Math.random() * trends.length)] as any,
      overall_signal: signals[Math.floor(Math.random() * signals.length)] as any,
      momentum: Math.random() > 0.5 ? 'bullish' : 'bearish',
      macd_direction: Math.random() > 0.5 ? 'bullish' : 'bearish',
      volume_confirmation: Math.random() > 0.5 ? 'increasing' : 'decreasing',
    },
    support_resistance: {
      support: [[basePrice * 0.95, 3], [basePrice * 0.92, 2]],
      resistance: [[basePrice * 1.05, 4], [basePrice * 1.08, 2]],
    }
  }
}

const AnalysisPanel: React.FC<AnalysisPanelProps> = ({ 
  symbol, 
  timeframe, 
  analysisData, 
  isLoading 
}) => {
  // Use mock data if no real data is available
  const analysis = analysisData || generateMockAnalysis(symbol, timeframe)
  
  const SignalBadge: React.FC<{ signal: string; className?: string }> = ({ signal, className }) => (
    <div className={cn(
      "px-3 py-1 rounded-full text-xs font-medium border",
      getSignalColor(signal),
      className
    )}>
      {signal.replace('_', ' ')}
    </div>
  )

  const TrendIndicator: React.FC<{ trend: string }> = ({ trend }) => {
    const Icon = trend === 'bullish' ? TrendingUp : trend === 'bearish' ? TrendingDown : Activity
    return (
      <div className={cn("flex items-center gap-2", getTrendColor(trend))}>
        <Icon className="w-4 h-4" />
        <span className="font-medium capitalize">{trend}</span>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Main Analysis Card */}
      <CyberCard>
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-neon-purple text-glow">
              Technical Analysis
            </h2>
            <div className="flex items-center gap-2 text-xs text-gray-400">
              <div className="w-2 h-2 bg-neon-green rounded-full animate-pulse"></div>
              Live
            </div>
          </div>

          <AnimatePresence mode="wait">
            {isLoading ? (
              <motion.div
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex items-center justify-center py-8"
              >
                <div className="flex flex-col items-center gap-3">
                  <div className="w-8 h-8 border-2 border-neon-purple/30 rounded-full animate-spin">
                    <div className="absolute top-0 left-0 w-2 h-2 bg-neon-purple rounded-full"></div>
                  </div>
                  <p className="text-sm text-neon-purple/80">Analyzing market data...</p>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="content"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-4"
              >
                {/* Overall Signal */}
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Overall Signal</span>
                  <SignalBadge signal={analysis.trading_signals.overall_signal} />
                </div>

                {/* Trend */}
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Market Trend</span>
                  <TrendIndicator trend={analysis.trading_signals.overall_bias} />
                </div>

                {/* Current Price */}
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Current Price</span>
                  <span className="font-mono text-neon-blue">
                    {formatPrice(analysis.current_price)}
                  </span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </CyberCard>

      {/* Key Levels */}
      <CyberCard>
        <div className="p-6">
          <h3 className="text-lg font-semibold text-neon-green text-glow mb-4 flex items-center gap-2">
            <Target className="w-5 h-5" />
            Key Levels
          </h3>
          
          <div className="space-y-3">
            {analysis.key_levels.key_resistance && (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-neon-pink"></div>
                  <span className="text-sm text-gray-400">Resistance</span>
                </div>
                <span className="font-mono text-neon-pink">
                  {formatPrice(analysis.key_levels.key_resistance)}
                </span>
              </div>
            )}
            
            <div className="flex items-center justify-between border-y border-neon-blue/20 py-2">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-neon-blue"></div>
                <span className="text-sm text-gray-400">Current</span>
              </div>
              <span className="font-mono text-neon-blue font-medium">
                {formatPrice(analysis.current_price)}
              </span>
            </div>
            
            {analysis.key_levels.key_support && (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-neon-green"></div>
                  <span className="text-sm text-gray-400">Support</span>
                </div>
                <span className="font-mono text-neon-green">
                  {formatPrice(analysis.key_levels.key_support)}
                </span>
              </div>
            )}
          </div>
        </div>
      </CyberCard>

      {/* Momentum Indicators */}
      <CyberCard>
        <div className="p-6">
          <h3 className="text-lg font-semibold text-neon-yellow text-glow mb-4 flex items-center gap-2">
            <Zap className="w-5 h-5" />
            Momentum
          </h3>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">RSI Signal</span>
              <div className={cn(
                "px-2 py-1 rounded text-xs",
                analysis.trading_signals.momentum === 'bullish' ? 'bg-neon-green/20 text-neon-green' :
                analysis.trading_signals.momentum === 'bearish' ? 'bg-neon-pink/20 text-neon-pink' :
                'bg-neon-blue/20 text-neon-blue'
              )}>
                {analysis.trading_signals.momentum}
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">MACD</span>
              <div className={cn(
                "px-2 py-1 rounded text-xs",
                analysis.trading_signals.macd_direction === 'bullish' ? 'bg-neon-green/20 text-neon-green' :
                'bg-neon-pink/20 text-neon-pink'
              )}>
                {analysis.trading_signals.macd_direction}
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Volume</span>
              <div className={cn(
                "px-2 py-1 rounded text-xs",
                analysis.trading_signals.volume_confirmation === 'increasing' ? 'bg-neon-green/20 text-neon-green' :
                analysis.trading_signals.volume_confirmation === 'decreasing' ? 'bg-neon-pink/20 text-neon-pink' :
                'bg-neon-blue/20 text-neon-blue'
              )}>
                {analysis.trading_signals.volume_confirmation}
              </div>
            </div>
          </div>
        </div>
      </CyberCard>

      {/* Analysis Summary */}
      <CyberCard>
        <div className="p-6">
          <h3 className="text-lg font-semibold text-neon-cyan text-glow mb-4 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5" />
            Market Summary
          </h3>
          
          <div className="prose prose-sm prose-invert">
            <p className="text-gray-300 text-sm leading-relaxed">
              {analysis.analysis_text}
            </p>
          </div>
          
          <div className="mt-4 pt-4 border-t border-neon-cyan/20">
            <div className="flex items-center gap-2 text-xs text-gray-400">
              <Shield className="w-3 h-3" />
              <span>Analysis updated: {new Date(analysis.analysis_time).toLocaleTimeString()}</span>
            </div>
          </div>
        </div>
      </CyberCard>
    </div>
  )
}

export { AnalysisPanel }
