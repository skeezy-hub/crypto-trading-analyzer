"""
Chart Generator Module for Crypto Trading Analyzer
Creates TradingView-style charts with candlesticks, indicators, volume, and support/resistance levels
"""

import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px
from datetime import datetime
from typing import Dict, List, Tuple, Optional
import os


class ChartGenerator:
    def __init__(self, df: pd.DataFrame, symbol: str, timeframe: str):
        """
        Initialize chart generator with OHLCV data
        
        Args:
            df: DataFrame with OHLCV data and indicators
            symbol: Trading symbol (e.g., 'BTC/USDT')
            timeframe: Timeframe (e.g., '1h', '4h', '1d')
        """
        self.df = df
        self.symbol = symbol
        self.timeframe = timeframe
        self.fig = None
        
        # Color scheme (TradingView-like)
        self.colors = {
            'background': '#1e222d',
            'grid': '#2a2e39',
            'text': '#d1d4dc',
            'green': '#4caf50',
            'red': '#f44336',
            'blue': '#2196f3',
            'orange': '#ff9800',
            'purple': '#9c27b0',
            'yellow': '#ffeb3b',
            'cyan': '#00bcd4',
            'volume': '#26a69a'
        }
    
    def create_chart(self, 
                     include_volume: bool = True,
                     include_rsi: bool = True,
                     include_macd: bool = True,
                     ema_periods: List[int] = [20, 50],
                     support_resistance: Optional[Dict] = None,
                     height: int = 800) -> go.Figure:
        """
        Create comprehensive TradingView-style chart
        
        Args:
            include_volume: Whether to include volume subplot
            include_rsi: Whether to include RSI subplot
            include_macd: Whether to include MACD subplot
            ema_periods: List of EMA periods to plot
            support_resistance: Dictionary with support and resistance levels
            height: Chart height in pixels
            
        Returns:
            Plotly figure object
        """
        # Calculate number of subplots
        subplot_count = 1  # Main price chart
        subplot_titles = [f'{self.symbol} - {self.timeframe}']
        
        if include_volume:
            subplot_count += 1
            subplot_titles.append('Volume')
        
        if include_rsi:
            subplot_count += 1
            subplot_titles.append('RSI (14)')
        
        if include_macd:
            subplot_count += 1
            subplot_titles.append('MACD')
        
        # Define subplot heights
        if subplot_count == 1:
            row_heights = [1.0]
        elif subplot_count == 2:
            row_heights = [0.7, 0.3]
        elif subplot_count == 3:
            row_heights = [0.6, 0.2, 0.2]
        else:
            row_heights = [0.5, 0.2, 0.15, 0.15]
        
        # Create subplots
        self.fig = make_subplots(
            rows=subplot_count,
            cols=1,
            shared_xaxes=True,
            vertical_spacing=0.03,
            subplot_titles=subplot_titles,
            row_heights=row_heights,
            specs=[[{"secondary_y": False}] for _ in range(subplot_count)]
        )
        
        # Add main price chart elements
        self._add_candlesticks()
        self._add_moving_averages(ema_periods)
        self._add_bollinger_bands()
        
        if support_resistance:
            self._add_support_resistance_levels(support_resistance)
        
        # Add subplots
        current_row = 2
        
        if include_volume:
            self._add_volume_chart(current_row)
            current_row += 1
        
        if include_rsi:
            self._add_rsi_chart(current_row)
            current_row += 1
        
        if include_macd:
            self._add_macd_chart(current_row)
        
        # Apply styling
        self._apply_styling(height)
        
        return self.fig
    
    def _add_candlesticks(self):
        """Add candlestick chart to main subplot"""
        self.fig.add_trace(
            go.Candlestick(
                x=self.df.index,
                open=self.df['open'],
                high=self.df['high'],
                low=self.df['low'],
                close=self.df['close'],
                name='Price',
                increasing_line_color=self.colors['green'],
                decreasing_line_color=self.colors['red'],
                increasing_fillcolor=self.colors['green'],
                decreasing_fillcolor=self.colors['red'],
            ),
            row=1, col=1
        )
    
    def _add_moving_averages(self, periods: List[int]):
        """Add EMA lines to main chart"""
        colors = [self.colors['blue'], self.colors['orange'], self.colors['purple'], self.colors['cyan']]
        
        for i, period in enumerate(periods):
            if f'EMA_{period}' in self.df.columns:
                color = colors[i % len(colors)]
                self.fig.add_trace(
                    go.Scatter(
                        x=self.df.index,
                        y=self.df[f'EMA_{period}'],
                        mode='lines',
                        name=f'EMA {period}',
                        line=dict(color=color, width=2),
                    ),
                    row=1, col=1
                )
    
    def _add_bollinger_bands(self):
        """Add Bollinger Bands to main chart"""
        if all(col in self.df.columns for col in ['BB_Upper', 'BB_Lower', 'BB_Middle']):
            # Upper band
            self.fig.add_trace(
                go.Scatter(
                    x=self.df.index,
                    y=self.df['BB_Upper'],
                    mode='lines',
                    name='BB Upper',
                    line=dict(color=self.colors['purple'], width=1, dash='dot'),
                    showlegend=False,
                ),
                row=1, col=1
            )
            
            # Lower band
            self.fig.add_trace(
                go.Scatter(
                    x=self.df.index,
                    y=self.df['BB_Lower'],
                    mode='lines',
                    name='BB Lower',
                    line=dict(color=self.colors['purple'], width=1, dash='dot'),
                    fill='tonexty',
                    fillcolor='rgba(156, 39, 176, 0.1)',
                    showlegend=False,
                ),
                row=1, col=1
            )
            
            # Middle band
            self.fig.add_trace(
                go.Scatter(
                    x=self.df.index,
                    y=self.df['BB_Middle'],
                    mode='lines',
                    name='BB Middle',
                    line=dict(color=self.colors['purple'], width=1),
                ),
                row=1, col=1
            )
    
    def _add_support_resistance_levels(self, levels: Dict):
        """Add support and resistance levels to main chart"""
        # Add support levels
        for level, strength in levels.get('support', []):
            self.fig.add_hline(
                y=level,
                line_dash="dash",
                line_color=self.colors['green'],
                line_width=2,
                opacity=min(0.3 + (strength * 0.1), 1.0),
                annotation_text=f"Support: ${level:.2f} ({strength})",
                annotation_position="right",
                row=1
            )
        
        # Add resistance levels
        for level, strength in levels.get('resistance', []):
            self.fig.add_hline(
                y=level,
                line_dash="dash",
                line_color=self.colors['red'],
                line_width=2,
                opacity=min(0.3 + (strength * 0.1), 1.0),
                annotation_text=f"Resistance: ${level:.2f} ({strength})",
                annotation_position="right",
                row=1
            )
    
    def _add_volume_chart(self, row: int):
        """Add volume chart subplot"""
        # Color volume bars based on price movement
        colors = []
        for i in range(len(self.df)):
            if i == 0:
                colors.append(self.colors['volume'])
            else:
                if self.df['close'].iloc[i] > self.df['close'].iloc[i-1]:
                    colors.append(self.colors['green'])
                else:
                    colors.append(self.colors['red'])
        
        self.fig.add_trace(
            go.Bar(
                x=self.df.index,
                y=self.df['volume'],
                name='Volume',
                marker_color=colors,
                opacity=0.7,
            ),
            row=row, col=1
        )
        
        # Add volume moving average
        if len(self.df) >= 20:
            volume_ma = self.df['volume'].rolling(window=20).mean()
            self.fig.add_trace(
                go.Scatter(
                    x=self.df.index,
                    y=volume_ma,
                    mode='lines',
                    name='Volume MA(20)',
                    line=dict(color=self.colors['orange'], width=2),
                ),
                row=row, col=1
            )
    
    def _add_rsi_chart(self, row: int):
        """Add RSI chart subplot"""
        if 'RSI' in self.df.columns:
            self.fig.add_trace(
                go.Scatter(
                    x=self.df.index,
                    y=self.df['RSI'],
                    mode='lines',
                    name='RSI',
                    line=dict(color=self.colors['purple'], width=2),
                ),
                row=row, col=1
            )
            
            # Add RSI levels
            self.fig.add_hline(y=70, line_dash="dash", line_color=self.colors['red'], 
                             line_width=1, opacity=0.5, row=row)
            self.fig.add_hline(y=50, line_dash="solid", line_color=self.colors['text'], 
                             line_width=1, opacity=0.3, row=row)
            self.fig.add_hline(y=30, line_dash="dash", line_color=self.colors['green'], 
                             line_width=1, opacity=0.5, row=row)
            
            # Set RSI y-axis range
            self.fig.update_yaxes(range=[0, 100], row=row, col=1)
    
    def _add_macd_chart(self, row: int):
        """Add MACD chart subplot"""
        if all(col in self.df.columns for col in ['MACD', 'MACD_Signal', 'MACD_Histogram']):
            # MACD line
            self.fig.add_trace(
                go.Scatter(
                    x=self.df.index,
                    y=self.df['MACD'],
                    mode='lines',
                    name='MACD',
                    line=dict(color=self.colors['blue'], width=2),
                ),
                row=row, col=1
            )
            
            # Signal line
            self.fig.add_trace(
                go.Scatter(
                    x=self.df.index,
                    y=self.df['MACD_Signal'],
                    mode='lines',
                    name='Signal',
                    line=dict(color=self.colors['red'], width=2),
                ),
                row=row, col=1
            )
            
            # Histogram
            colors = ['green' if val >= 0 else 'red' for val in self.df['MACD_Histogram']]
            self.fig.add_trace(
                go.Bar(
                    x=self.df.index,
                    y=self.df['MACD_Histogram'],
                    name='Histogram',
                    marker_color=colors,
                    opacity=0.6,
                ),
                row=row, col=1
            )
            
            # Zero line
            self.fig.add_hline(y=0, line_dash="solid", line_color=self.colors['text'], 
                             line_width=1, opacity=0.3, row=row)
    
    def _apply_styling(self, height: int):
        """Apply TradingView-like styling to the chart"""
        self.fig.update_layout(
            title=dict(
                text=f"{self.symbol} Technical Analysis - {self.timeframe}",
                x=0.5,
                font=dict(size=20, color=self.colors['text'])
            ),
            paper_bgcolor=self.colors['background'],
            plot_bgcolor=self.colors['background'],
            font=dict(color=self.colors['text']),
            height=height,
            showlegend=True,
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1,
                bgcolor='rgba(30, 34, 45, 0.8)',
                bordercolor=self.colors['grid'],
                borderwidth=1
            ),
            margin=dict(l=50, r=50, t=80, b=50),
            hovermode='x unified',
        )
        
        # Update all axes
        self.fig.update_xaxes(
            gridcolor=self.colors['grid'],
            showgrid=True,
            zeroline=False,
            showspikes=True,
            spikethickness=1,
            spikecolor=self.colors['text'],
            spikemode='across',
        )
        
        self.fig.update_yaxes(
            gridcolor=self.colors['grid'],
            showgrid=True,
            zeroline=False,
            side='right',
            showspikes=True,
            spikethickness=1,
            spikecolor=self.colors['text'],
        )
        
        # Remove rangeslider from candlestick chart
        self.fig.update_layout(xaxis_rangeslider_visible=False)
    
    def save_chart(self, filename: str = None, format: str = 'png', width: int = 1400, height: int = 800):
        """
        Save chart as image
        
        Args:
            filename: Output filename (auto-generated if None)
            format: Output format ('png', 'jpg', 'svg', 'pdf', 'html')
            width: Image width in pixels
            height: Image height in pixels
        """
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            symbol_clean = self.symbol.replace('/', '_')
            filename = f"{symbol_clean}_{self.timeframe}_{timestamp}"
        
        if format.lower() == 'html':
            self.fig.write_html(f"{filename}.html")
            print(f"Chart saved as {filename}.html")
        else:
            self.fig.write_image(f"{filename}.{format}", width=width, height=height)
            print(f"Chart saved as {filename}.{format}")
        
        return f"{filename}.{format}" if format != 'html' else f"{filename}.html"
    
    def add_annotations(self, annotations: List[Dict]):
        """
        Add custom annotations to the chart
        
        Args:
            annotations: List of annotation dictionaries with keys:
                - x: x-coordinate (timestamp or index)
                - y: y-coordinate (price)
                - text: annotation text
                - arrow: whether to show arrow (default True)
                - color: text color (optional)
        """
        for ann in annotations:
            self.fig.add_annotation(
                x=ann['x'],
                y=ann['y'],
                text=ann['text'],
                showarrow=ann.get('arrow', True),
                arrowhead=2,
                arrowsize=1,
                arrowwidth=2,
                arrowcolor=ann.get('color', self.colors['text']),
                font=dict(color=ann.get('color', self.colors['text']), size=12),
                bgcolor='rgba(30, 34, 45, 0.8)',
                bordercolor=ann.get('color', self.colors['text']),
                borderwidth=1,
                row=1, col=1
            )
    
    def show_chart(self):
        """Display the chart"""
        if self.fig:
            self.fig.show()
        else:
            print("No chart created yet. Call create_chart() first.")


# Example usage
if __name__ == "__main__":
    print("Chart Generator module loaded successfully")
    print("Use with OHLCV DataFrame and indicators to generate charts")
