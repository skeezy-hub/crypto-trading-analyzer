"""
Data Fetcher Module for Crypto Trading Analyzer
Handles fetching OHLCV data from various exchanges using ccxt
"""

import ccxt
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import time
from typing import Optional, Dict, Any, List, Tuple


class DataFetcher:
    def __init__(self, exchange_name: str = 'binance'):
        """
        Initialize the data fetcher with a specific exchange
        
        Args:
            exchange_name: Name of the exchange to use (default: binance)
        """
        self.exchange_name = exchange_name
        self.exchange = self._initialize_exchange(exchange_name)
        
    def _initialize_exchange(self, exchange_name: str) -> ccxt.Exchange:
        """Initialize the exchange object"""
        try:
            exchange_class = getattr(ccxt, exchange_name.lower())
            exchange = exchange_class({
                'apiKey': '',
                'secret': '',
                'timeout': 30000,
                'enableRateLimit': True,
                'sandbox': False,
            })
            return exchange
        except Exception as e:
            print(f"Error initializing {exchange_name}: {e}")
            # Fallback to Binance if the specified exchange fails
            return ccxt.binance({
                'timeout': 30000,
                'enableRateLimit': True,
            })
    
    def get_ohlcv_data(self, 
                       symbol: str, 
                       timeframe: str = '1h', 
                       limit: int = 500,
                       start_date: Optional[datetime] = None) -> pd.DataFrame:
        """
        Fetch OHLCV data for a given symbol and timeframe
        
        Args:
            symbol: Trading pair symbol (e.g., 'BTC/USDT')
            timeframe: Timeframe for the data (e.g., '1m', '5m', '15m', '1h', '4h', '1d')
            limit: Number of candles to fetch (max depends on exchange)
            start_date: Optional start date for historical data
            
        Returns:
            DataFrame with OHLCV data
        """
        try:
            # Validate symbol format
            if '/' not in symbol:
                symbol = f"{symbol}/USDT"  # Default to USDT pair
                
            # Convert symbol to exchange format
            symbol = symbol.upper()
            
            # Fetch data
            if start_date:
                since = int(start_date.timestamp() * 1000)
                ohlcv = self.exchange.fetch_ohlcv(symbol, timeframe, since, limit)
            else:
                ohlcv = self.exchange.fetch_ohlcv(symbol, timeframe, limit=limit)
            
            if not ohlcv:
                raise ValueError(f"No data returned for {symbol}")
            
            # Convert to DataFrame
            df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            df.set_index('timestamp', inplace=True)
            
            # Ensure numeric types
            numeric_columns = ['open', 'high', 'low', 'close', 'volume']
            for col in numeric_columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
            
            # Remove any rows with NaN values
            df = df.dropna()
            
            print(f"Fetched {len(df)} candles for {symbol} ({timeframe})")
            return df
            
        except Exception as e:
            print(f"Error fetching data for {symbol}: {e}")
            return pd.DataFrame()
    
    def get_current_price(self, symbol: str) -> float:
        """Get current price for a symbol"""
        try:
            if '/' not in symbol:
                symbol = f"{symbol}/USDT"
            
            ticker = self.exchange.fetch_ticker(symbol.upper())
            return float(ticker['last'])
        except Exception as e:
            print(f"Error fetching current price for {symbol}: {e}")
            return 0.0
    
    def get_available_symbols(self) -> List[str]:
        """Get list of available trading symbols"""
        try:
            markets = self.exchange.load_markets()
            symbols = [symbol for symbol in markets.keys() if '/USDT' in symbol]
            return sorted(symbols)
        except Exception as e:
            print(f"Error fetching available symbols: {e}")
            return []
    
    def validate_symbol(self, symbol: str) -> bool:
        """Validate if a symbol is available on the exchange"""
        try:
            if '/' not in symbol:
                symbol = f"{symbol}/USDT"
            
            markets = self.exchange.load_markets()
            return symbol.upper() in markets
        except Exception as e:
            print(f"Error validating symbol {symbol}: {e}")
            return False
    
    def get_timeframe_minutes(self, timeframe: str) -> int:
        """Convert timeframe string to minutes"""
        timeframe_map = {
            '1m': 1,
            '3m': 3,
            '5m': 5,
            '15m': 15,
            '30m': 30,
            '1h': 60,
            '2h': 120,
            '4h': 240,
            '6h': 360,
            '8h': 480,
            '12h': 720,
            '1d': 1440,
            '3d': 4320,
            '1w': 10080,
        }
        return timeframe_map.get(timeframe, 60)
    
    def get_historical_data_range(self, 
                                  symbol: str, 
                                  timeframe: str,
                                  days_back: int = 30) -> pd.DataFrame:
        """
        Get historical data for a specific number of days back
        
        Args:
            symbol: Trading pair symbol
            timeframe: Timeframe for the data
            days_back: Number of days to go back
            
        Returns:
            DataFrame with historical OHLCV data
        """
        try:
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days_back)
            
            # Calculate the number of candles needed
            timeframe_minutes = self.get_timeframe_minutes(timeframe)
            total_minutes = days_back * 24 * 60
            estimated_candles = min(total_minutes // timeframe_minutes, 1000)
            
            return self.get_ohlcv_data(symbol, timeframe, estimated_candles, start_date)
            
        except Exception as e:
            print(f"Error fetching historical data: {e}")
            return pd.DataFrame()


# Example usage and testing
if __name__ == "__main__":
    # Test the data fetcher
    fetcher = DataFetcher()
    
    # Test with BTC/USDT
    print("Testing DataFetcher with BTC/USDT...")
    df = fetcher.get_ohlcv_data('BTC/USDT', '1h', 100)
    
    if not df.empty:
        print(f"Data shape: {df.shape}")
        print(f"Date range: {df.index[0]} to {df.index[-1]}")
        print(f"Current price: ${fetcher.get_current_price('BTC/USDT'):,.2f}")
        print("\nFirst 5 rows:")
        print(df.head())
    else:
        print("No data fetched")
