"""
Technical Analysis Engine for Crypto Trading Analyzer
Generates professional trader-style technical analysis writeups
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
from technical_indicators import TechnicalIndicators


class AnalysisEngine:
    def __init__(self, df: pd.DataFrame, symbol: str, timeframe: str):
        """
        Initialize analysis engine
        
        Args:
            df: DataFrame with OHLCV data and indicators
            symbol: Trading symbol (e.g., 'BTC/USDT')
            timeframe: Timeframe (e.g., '1h', '4h', '1d')
        """
        self.df = df
        self.symbol = symbol
        self.timeframe = timeframe
        self.indicators = TechnicalIndicators(df)
        self.current_price = df['close'].iloc[-1] if not df.empty else 0
        
        # Calculate all indicators
        self.indicators.get_all_indicators()
        self.signals = self.indicators.get_current_signals()
        
    def generate_analysis(self) -> str:
        """Generate comprehensive technical analysis writeup"""
        analysis_parts = []
        
        # Header with current market status
        analysis_parts.append(self._generate_header())
        
        # Market trend analysis
        analysis_parts.append(self._analyze_trend())
        
        # Support and resistance analysis
        analysis_parts.append(self._analyze_support_resistance())
        
        # Momentum indicators analysis
        analysis_parts.append(self._analyze_momentum())
        
        # Volume analysis
        analysis_parts.append(self._analyze_volume())
        
        # Trading scenarios and outlook
        analysis_parts.append(self._generate_scenarios())
        
        # Risk management considerations
        analysis_parts.append(self._analyze_risk_reward())
        
        return "\n\n".join(analysis_parts)
    
    def _generate_header(self) -> str:
        """Generate analysis header with current market status"""
        price_change = self._calculate_price_change()
        price_change_pct = (price_change / self.df['close'].iloc[-20] * 100) if len(self.df) >= 20 else 0
        
        change_direction = "higher" if price_change > 0 else "lower"
        change_color = "📈" if price_change > 0 else "📉"
        
        header = f"""🔍 TECHNICAL ANALYSIS: {self.symbol} ({self.timeframe.upper()})
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Current Price: ${self.current_price:,.2f} {change_color}
24h Change: {price_change_pct:+.2f}% ({change_direction} by ${abs(price_change):,.2f})
Analysis Time: {datetime.now().strftime('%Y-%m-%d %H:%M UTC')}
Market Trend: {self.signals.get('trend', 'Unknown').upper()}"""
        
        return header
    
    def _analyze_trend(self) -> str:
        """Analyze overall market trend"""
        trend = self.signals.get('trend', 'sideways')
        
        # Get EMA values for context
        ema_20 = self.indicators.indicators.get('EMA_20', pd.Series()).iloc[-1] if 'EMA_20' in self.indicators.indicators else None
        ema_50 = self.indicators.indicators.get('EMA_50', pd.Series()).iloc[-1] if 'EMA_50' in self.indicators.indicators else None
        
        trend_analysis = "📊 TREND ANALYSIS\n" + "─" * 20
        
        if trend == 'bullish':
            trend_analysis += f"""
The market is displaying strong bullish momentum. Price is trading at ${self.current_price:,.2f}, maintaining position above key moving averages."""
            
            if ema_20 and ema_50:
                if ema_20 > ema_50:
                    trend_analysis += f" The 20 EMA (${ema_20:,.2f}) has crossed above the 50 EMA (${ema_50:,.2f}), confirming the upward bias."
                
            trend_analysis += " This setup suggests continued strength with buyers in control of the market structure."
            
        elif trend == 'bearish':
            trend_analysis += f"""
The market is in a bearish phase with selling pressure dominating. Price at ${self.current_price:,.2f} is showing weakness against major moving averages."""
            
            if ema_20 and ema_50:
                if ema_20 < ema_50:
                    trend_analysis += f" The 20 EMA (${ema_20:,.2f}) remains below the 50 EMA (${ema_50:,.2f}), reinforcing the downward trajectory."
                    
            trend_analysis += " Bears are in control, and any rallies are likely to be met with selling pressure."
            
        else:  # sideways
            trend_analysis += f"""
The market is consolidating in a sideways pattern around ${self.current_price:,.2f}. This consolidation phase indicates indecision between buyers and sellers."""
            
            if ema_20 and ema_50:
                ema_diff_pct = abs(ema_20 - ema_50) / ema_50 * 100 if ema_50 else 0
                if ema_diff_pct < 2:
                    trend_analysis += f" Moving averages are converging (20 EMA: ${ema_20:,.2f}, 50 EMA: ${ema_50:,.2f}), suggesting a potential breakout is approaching."
                    
            trend_analysis += " Watch for a decisive break above resistance or below support to determine the next directional move."
        
        return trend_analysis
    
    def _analyze_support_resistance(self) -> str:
        """Analyze support and resistance levels"""
        support_levels = self.signals.get('support_levels', [])
        resistance_levels = self.signals.get('resistance_levels', [])
        
        sr_analysis = "🎯 SUPPORT & RESISTANCE\n" + "─" * 25
        
        if resistance_levels:
            key_resistance = resistance_levels[0][0]  # Strongest resistance
            sr_analysis += f"""
Key resistance sits at ${key_resistance:,.2f}, which has been tested {resistance_levels[0][1]} times. This level represents a critical barrier that bulls need to overcome."""
            
            distance_to_resistance = ((key_resistance - self.current_price) / self.current_price) * 100
            if distance_to_resistance < 2:
                sr_analysis += f" Price is currently just {distance_to_resistance:.1f}% away from this resistance, making it a crucial level to watch."
        
        if support_levels:
            key_support = support_levels[0][0]  # Strongest support
            sr_analysis += f"""
Strong support is established at ${key_support:,.2f}, validated by {support_levels[0][1]} previous touches. This level should provide a floor for any potential pullbacks."""
            
            distance_to_support = ((self.current_price - key_support) / self.current_price) * 100
            if distance_to_support < 5:
                sr_analysis += f" With price only {distance_to_support:.1f}% above this support, it's a critical level for maintaining the current structure."
        
        # Add additional levels context
        if len(resistance_levels) > 1:
            next_resistance = resistance_levels[1][0]
            sr_analysis += f" Secondary resistance at ${next_resistance:,.2f} provides the next upside target."
            
        if len(support_levels) > 1:
            next_support = support_levels[1][0]
            sr_analysis += f" Additional support at ${next_support:,.2f} offers a backup level if primary support fails."
        
        return sr_analysis
    
    def _analyze_momentum(self) -> str:
        """Analyze momentum indicators (RSI, MACD)"""
        rsi = self.signals.get('rsi')
        rsi_signal = self.signals.get('rsi_signal', 'neutral')
        macd_signal = self.signals.get('macd_signal', 'neutral')
        
        momentum_analysis = "⚡ MOMENTUM INDICATORS\n" + "─" * 22
        
        # RSI Analysis
        if rsi:
            momentum_analysis += f"""
RSI is currently at {rsi:.1f}, indicating {rsi_signal} conditions."""
            
            if rsi_signal == 'overbought':
                momentum_analysis += " This suggests the market may be due for a pullback or consolidation phase."
            elif rsi_signal == 'oversold':
                momentum_analysis += " This indicates potential for a bounce or reversal from current levels."
            elif rsi_signal == 'bullish':
                momentum_analysis += " This shows healthy upward momentum without extreme overbought conditions."
            elif rsi_signal == 'bearish':
                momentum_analysis += " This reflects ongoing selling pressure and bearish sentiment."
        
        # MACD Analysis
        macd_line = self.indicators.indicators.get('MACD', pd.Series()).iloc[-1] if 'MACD' in self.indicators.indicators else None
        macd_signal_line = self.indicators.indicators.get('MACD_Signal', pd.Series()).iloc[-1] if 'MACD_Signal' in self.indicators.indicators else None
        
        if macd_line is not None and macd_signal_line is not None:
            if macd_signal == 'bullish':
                momentum_analysis += f" MACD line ({macd_line:.4f}) is above the signal line ({macd_signal_line:.4f}), confirming bullish momentum."
            else:
                momentum_analysis += f" MACD line ({macd_line:.4f}) is below the signal line ({macd_signal_line:.4f}), suggesting bearish momentum."
        
        return momentum_analysis
    
    def _analyze_volume(self) -> str:
        """Analyze volume trends"""
        volume_trend = self.signals.get('volume_trend', 'stable')
        
        volume_analysis = "📊 VOLUME ANALYSIS\n" + "─" * 17
        
        current_volume = self.df['volume'].iloc[-1]
        avg_volume = self.df['volume'].tail(20).mean() if len(self.df) >= 20 else current_volume
        
        volume_ratio = current_volume / avg_volume if avg_volume > 0 else 1
        
        if volume_trend == 'increasing':
            volume_analysis += f"""
Volume is trending higher with current levels at {volume_ratio:.1f}x the 20-period average. This increased participation validates the current price movement and suggests genuine interest from market participants."""
            
        elif volume_trend == 'decreasing':
            volume_analysis += f"""
Volume is declining with current levels at {volume_ratio:.1f}x the 20-period average. This lack of participation suggests caution, as price movements may lack conviction without volume confirmation."""
            
        else:  # stable
            volume_analysis += f"""
Volume remains relatively stable around average levels ({volume_ratio:.1f}x average). This suggests normal market activity without extreme buying or selling pressure."""
        
        return volume_analysis
    
    def _generate_scenarios(self) -> str:
        """Generate bullish and bearish scenarios"""
        support_levels = self.signals.get('support_levels', [])
        resistance_levels = self.signals.get('resistance_levels', [])
        
        scenarios = "🎲 TRADING SCENARIOS\n" + "─" * 18
        
        # Bullish scenario
        scenarios += "\n\n🟢 BULLISH SCENARIO:"
        if resistance_levels:
            first_target = resistance_levels[0][0]
            second_target = resistance_levels[1][0] if len(resistance_levels) > 1 else first_target * 1.05
            
            scenarios += f"""
A break above ${first_target:,.2f} resistance would confirm bullish continuation. Initial target sits at ${second_target:,.2f}, representing a {((second_target - self.current_price) / self.current_price * 100):+.1f}% move from current levels. Strong volume on the breakout would validate this scenario."""
        
        # Bearish scenario
        scenarios += "\n\n🔴 BEARISH SCENARIO:"
        if support_levels:
            first_support = support_levels[0][0]
            second_support = support_levels[1][0] if len(support_levels) > 1 else first_support * 0.95
            
            scenarios += f"""
A breakdown below ${first_support:,.2f} support would trigger bearish momentum toward ${second_support:,.2f}, implying a {((second_support - self.current_price) / self.current_price * 100):+.1f}% decline. Watch for increased selling volume to confirm the breakdown."""
        else:
            # If no support levels found, use a percentage-based target
            bearish_target = self.current_price * 0.95
            scenarios += f"""
Without clear support levels, a bearish breakdown could target ${bearish_target:,.2f}, representing a -5.0% decline from current levels. Monitor for increased selling pressure and volume confirmation."""
        
        return scenarios
    
    def _analyze_risk_reward(self) -> str:
        """Analyze risk/reward considerations"""
        support_levels = self.signals.get('support_levels', [])
        resistance_levels = self.signals.get('resistance_levels', [])
        
        risk_analysis = "⚖️ RISK/REWARD ANALYSIS\n" + "─" * 22
        
        if support_levels and resistance_levels:
            nearest_support = support_levels[0][0]
            nearest_resistance = resistance_levels[0][0]
            
            risk_distance = self.current_price - nearest_support
            reward_distance = nearest_resistance - self.current_price
            
            risk_reward_ratio = reward_distance / risk_distance if risk_distance > 0 else 0
            
            risk_analysis += f"""
Current positioning offers a risk/reward ratio of {risk_reward_ratio:.2f}:1. Risk to support at ${nearest_support:,.2f} is ${risk_distance:,.2f} ({(risk_distance/self.current_price*100):.1f}%), while potential reward to resistance at ${nearest_resistance:,.2f} is ${reward_distance:,.2f} ({(reward_distance/self.current_price*100):.1f}%)."""
            
            if risk_reward_ratio >= 2:
                risk_analysis += " This presents a favorable risk/reward setup for potential long positions."
            elif risk_reward_ratio >= 1:
                risk_analysis += " The risk/reward is acceptable but requires careful position sizing."
            else:
                risk_analysis += " Current risk/reward favors waiting for better entry levels."
        
        # Add volatility context
        if 'ATR' in self.indicators.indicators:
            atr = self.indicators.indicators['ATR'].iloc[-1]
            atr_pct = (atr / self.current_price) * 100
            risk_analysis += f"""
Average True Range indicates daily volatility of ${atr:,.2f} ({atr_pct:.1f}%), which should guide position sizing and stop-loss placement."""
        
        return risk_analysis
    
    def _calculate_price_change(self) -> float:
        """Calculate price change over the last 20 periods"""
        if len(self.df) < 20:
            return 0
        return self.df['close'].iloc[-1] - self.df['close'].iloc[-20]
    
    def get_key_levels(self) -> Dict[str, float]:
        """Get key support and resistance levels"""
        support_levels = self.signals.get('support_levels', [])
        resistance_levels = self.signals.get('resistance_levels', [])
        
        return {
            'current_price': self.current_price,
            'key_support': support_levels[0][0] if support_levels else None,
            'key_resistance': resistance_levels[0][0] if resistance_levels else None,
            'secondary_support': support_levels[1][0] if len(support_levels) > 1 else None,
            'secondary_resistance': resistance_levels[1][0] if len(resistance_levels) > 1 else None,
        }
    
    def get_trading_signals(self) -> Dict[str, str]:
        """Get actionable trading signals"""
        signals = {
            'overall_bias': self.signals.get('trend', 'neutral'),
            'momentum': self.signals.get('rsi_signal', 'neutral'),
            'macd_direction': self.signals.get('macd_signal', 'neutral'),
            'volume_confirmation': self.signals.get('volume_trend', 'stable'),
        }
        
        # Generate overall signal
        bullish_signals = sum([
            signals['overall_bias'] == 'bullish',
            signals['momentum'] in ['bullish', 'oversold'],
            signals['macd_direction'] == 'bullish',
            signals['volume_confirmation'] == 'increasing'
        ])
        
        bearish_signals = sum([
            signals['overall_bias'] == 'bearish',
            signals['momentum'] in ['bearish', 'overbought'],
            signals['macd_direction'] == 'bearish',
            signals['volume_confirmation'] == 'decreasing'
        ])
        
        if bullish_signals >= 3:
            signals['overall_signal'] = 'STRONG_BUY'
        elif bullish_signals >= 2:
            signals['overall_signal'] = 'BUY'
        elif bearish_signals >= 3:
            signals['overall_signal'] = 'STRONG_SELL'
        elif bearish_signals >= 2:
            signals['overall_signal'] = 'SELL'
        else:
            signals['overall_signal'] = 'HOLD'
        
        return signals


# Example usage
if __name__ == "__main__":
    print("Analysis Engine module loaded successfully")
    print("Use with OHLCV DataFrame to generate technical analysis")
